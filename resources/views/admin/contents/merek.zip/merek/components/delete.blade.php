@csrf
@method("DELETE")
<h4>Apakah anda yakin ingin menghapus data ini?</h4>